(function() {
	var PATH_NAME_PATENTES = "/ConsultaPat";

	if (location.pathname.match(PATH_NAME_PATENTES)) {
		ConsultaPatPage();
	}

})();